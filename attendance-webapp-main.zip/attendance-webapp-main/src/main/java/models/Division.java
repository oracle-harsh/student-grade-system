package models;

public class Division {
    private String divisionName;

    public Division(String divisionName) {
        this.divisionName = divisionName;
    }

    // Getters and Setters

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }
}